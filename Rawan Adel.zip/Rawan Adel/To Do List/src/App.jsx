import CrudApp from "./components/CrudApp/CrudApp";
import TodoList from "./components/TodoList/TodoList";
import "./styless.css";

export default function App() {
  return (
    <div className="app-container">
      <h1>To Do list </h1>
      <div className="components-wrapper">
        <CrudApp />
        <TodoList />
      </div>
    </div>
  );
}
